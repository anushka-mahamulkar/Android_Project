package com.example.jewelapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.jewelapp.databinding.ActivityLoginPageBinding;

public class LoginPage extends AppCompatActivity {
    ActivityLoginPageBinding binding;
    DatabaseHelper databaseHelper;
    helper helper;
    helperclass helperclass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginPageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        helper=new helper(this);
        helperclass=new helperclass(this);

//        databaseHelper = new DatabaseHelper(this);

        binding.login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = binding.email.getText().toString();
                String password = binding.password.getText().toString();

                if (email.equals("")||password.equals("")){
                    Toast.makeText(LoginPage.this, "All fields are mandatory", Toast.LENGTH_SHORT).show();
                }else{
                    Cursor res = helperclass.login(email,password);

                    if (res.getCount()>0){
                        Toast.makeText(LoginPage.this, "Login Successfull", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(),dashboard.class);
                        startActivity(intent);
                    }else{
                        Toast.makeText(LoginPage.this, "invalid credentials", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        binding.register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),signup.class);
                startActivity(intent);
            }
        });


    }
}